import { createContext, useContext, useEffect, useState } from "react";
import jwtDecode from "jwt-decode";
import axiosInstance from "../api/axiosInstance";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [auth, setAuth] = useState({
        isAuthenticated: false,
        role: null,           // user | admin | superadmin
        token: null,
        loading: true,
    });

    // Restore session from localStorage
    useEffect(() => {
        const token = localStorage.getItem("token");

        if (!token) {
            setAuth({ isAuthenticated: false, role: null, token: null, loading: false });
            return;
        }

        try {
            const decoded = jwtDecode(token);

            if (decoded.exp * 1000 < Date.now()) {
                logout();
            } else {
                setAuth({
                    isAuthenticated: true,
                    role: decoded.role,
                    token,
                    loading: false,
                });

                axiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
            }

        } catch (err) {
            console.error("Invalid token:", err);
            logout();
        }
    }, []);

    // Login function
    const login = (token) => {
        const decoded = jwtDecode(token);

        localStorage.setItem("token", token);
        axiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;

        setAuth({
            isAuthenticated: true,
            role: decoded.role,
            token,
            loading: false,
        });
    };

    // Logout function
    const logout = () => {
        localStorage.removeItem("token");
        delete axiosInstance.defaults.headers.common["Authorization"];

        setAuth({
            isAuthenticated: false,
            role: null,
            token: null,
            loading: false,
        });
    };

    const value = {
        ...auth,
        login,
        logout,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
